console.log("java script working")
const togglesidebar=()=>{
	
	if($('.sidebar').is(":visible")){
		
		//true means we have to hide the sidebar
		
		$(".sidebar").css("display","none");
		$(".content").css("margin-left","0%");
	}else{
		//false means we have to show side bar
		$(".sidebar").css("display","block");
		$(".content").css("margin-left","30%");
		
	}
	
	
};